const products = [
  {id:1, name:'iPhone',price:800},
  {id:2, name:'iMac',price:1600},
  {id:3, name:'iWatch',price:650},
  {id:4, name:'iPad',price:1650}
]

module.exports = {
  products
}
