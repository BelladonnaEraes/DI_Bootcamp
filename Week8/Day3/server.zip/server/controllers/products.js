const {getAllProducts, getOneProduct} = require('../Modules/products.js')
//get all products
const _getAllProducts = (req,res)=> {
    getAllProducts('products')
  .then(data=>{
    res.json(data)
  })
  .catch(e=>{
    console.log(e);
    res.status(404).json({msg:'Not Found'})
  })
}

const _getOneProduct = (req, res) => {
  getOneProduct(req.params.id)
  .then(data=>{
    res.json(data)
  })
  .catch(e=>{
    console.log(e);
    res.status(404).json({msg:'Not Found'})
  })
}


module.exports ={
  _getAllProducts,
  _getOneProduct
}
