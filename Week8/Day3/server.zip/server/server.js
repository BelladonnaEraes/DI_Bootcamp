const express = require('express');
//const knex = require('knex');
const dotenv = require('dotenv');
//const {db} = require('./connectionss/hrom.js')
const {getAllProducts} = require('./Modules/products.js')
dotenv.config()
const products_router = require('./routs/products.js')
const app = express();

/*app.get('/api/products',(req,res)=>{
  getAllProducts('products')
  //.select('id','name','price')
  .then(data=>{
    res.json(data)
  })
  .catch(e=>{
    console.log(e);
    res.status(404).json({msg:'Not Found'})
  })
})*/
app.use('/api/products', products_router)


app.listen(process.env.PORT, ()=>{
  console.log(`Server is running on port ${process.env.PORT}`);
})
