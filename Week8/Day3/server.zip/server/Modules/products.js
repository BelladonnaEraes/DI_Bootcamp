const {db} = require('../connectionss/hrom.js')

const getAllProducts = () => {
  return db('products')
  .select('id','name','price')
  .orderBy('name')
}

const getOneProduct =(product_id) => {
  return db ('products')
  .select('*')
  .where({id:product_id})
}

const searchProduct =(name)=> {
  return db ('products')
  .select('*')
  .whereILike ('name', `${name}%`)
}
module.exports = {
  getAllProducts,
  getOneProduct,
  searchProduct
}
