const express = require('express');
const router = express.Router();
const {getAllProducts, getOneProduct}  = require('../controllers/products.js')


router.get('./:id', _getOneProduct)
router.get('./all', _getAllProducts)

module.exports = router
