const Search = (props) => {
  console.log(props);
  return(
    <div>
      <input type="text" placeholder="Search####" />
      <button>Search</button>
    </div>
  )
}
export default Search
