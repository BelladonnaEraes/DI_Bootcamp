import React from 'react';
import myusers from './users.json';
import User from './components/User'
import 'tachyons'

class App extends React.Component {
  constructor() {
    super();
    this.state = {
      users: []
    }
  }

  getUsers = () => {
    this.setState({users:myusers})
  }
  render(){
    console.log('users=> ',this.state.users);
    return(
      <div>
        <button onClick={this.getUsers}>Show Users</button>
        <div>
        {
          this.state.users.map(item =>{
            return <User data={item} key={item.id}/>
          })
        }
        </div>
      </div>
    )
  }
}
export default App
