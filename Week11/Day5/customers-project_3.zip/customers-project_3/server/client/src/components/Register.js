const Register =(props)=>{
  return(
    <div style={{
      width:'300px',
      margin:'10px auto'
    }}>
     <h2>Register</h2>
    </div>
  )

}

export default Register
