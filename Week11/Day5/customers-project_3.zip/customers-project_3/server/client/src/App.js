import Customers from './components/Customers'
import Customer from './components/Customer'
import Loggin from './components/Loggin'
import Register from './components/Register'
import './App.css';
import {Routes,Route, Link} from 'react-router-dom';

function App() {
  return (
    <>
    <nav style={{padding:'20px', backgroundColor:'grey'}}>
    <Link to='/' style={{padding:'20px'}}>List</Link>
    <Link to='/signin' style={{padding:'20px'}}>Sign in</Link>
    <Link to='/signup' style={{padding:'20px'}}>Sign up</Link>
    </nav>
    <Routes>
      <Route path='/' element={<Customers />} />
      <Route path='/data/:id' element={<Customer />} />
      <Route path='/signin' element={<Loggin />} />
      <Route path='/signup' element={<Register />} />
    </Routes>

    </>
  );
}

export default App;
