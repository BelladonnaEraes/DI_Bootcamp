import {useEffect,useState} from 'react';
import {useParams, useNavigate, Link} from 'react-router-dom';
import axios from 'axios'

const Customer = (props) => {
  const [customer, setCustomer] = useState([])
  const [fname, setFname] = useState('')
  const [lname, setLname] = useState('')
  const params = useParams();
  const navigate = useNavigate();

  useEffect(()=>{
    getData();
  },[])

  const getData = async() => {
    try{
      const result = await axios.get(`/customer/${params.id}`);
      setCustomer(result.data);
    }
    catch(e){
      console.log(e);
    }
  }

  const update = async (e) => {
    e.preventDefault();
    try{
      const result = await axios.put(`/update/${params.id}`,{
        first_name:fname, last_name:lname
      })
      if(result.status==200){
        getData();
      }
    }
    catch(e){
      console.log(e);
    }
  }

  return(
    <div style={{
      width:'300px',
      margin:'10px auto'
    }}>
      <h2>Customer Data</h2>
      {
        customer.length === 0 ?
         ( 'Loading Customer Data....') :
         (
          <>
           <div >
            {customer[0].first_name}
            </div>
            <div >
            {customer[0].last_name}
            </div>
            <div >
            {customer[0].email}
            </div>
            <div >
            {customer[0].address}
            </div>
            <div >
            {customer[0].district}
            </div>
            <div >
            {customer[0].city}
            </div>
            <div >
            {customer[0].country}
            </div>
          </>
        )
      }
      <button onClick={()=>{navigate('/')}}>Back to List...</button>
      <div>
        <form onSubmit={update}>
          <input type='text' placeholder='First name'
                  onChange={(e)=>setFname(e.target.value) }/><br/>
          <input type='text' placeholder='Last name'
                  onChange={(e)=>setLname(e.target.value)}/><br/>
          <input type='submit' value='Update' />
        </form>
      </div>
    </div>
  )
}
export default Customer
