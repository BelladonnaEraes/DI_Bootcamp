import {createContext, useState} from 'react';
import Customers from './components/Customers'
import Customer from './components/Customer'
import Login from './components/Login'
import Register from './components/Register'
import './App.css';
import {Routes,Route, Link} from 'react-router-dom';

export const AppContext = createContext(null);

function App() {
  const [token, setToken] = useState('');
  return (
    <AppContext.Provider value={{token,setToken}}>
      <nav style={{
        padding:'20px',
        backgroundColor:'#ccc',
        fontSize:'20px'
      }}>
        <Link to='/' style={{padding:'0 10px'}}>List</Link>
        <Link to='/signin' style={{padding:'0 10px'}}>SignIn</Link>
        <Link to='/signup' style={{padding:'0 10px'}}>SignUp</Link>
      </nav>
      <Routes>
        <Route path='/' element={<Customers />} />
        <Route path='/data/:id' element={<Customer />} />
        <Route path='/signin' element={<Login />} />
        <Route path='/signup' element={<Register />} />
      </Routes>
    </AppContext.Provider>
  );
}

export default App;
