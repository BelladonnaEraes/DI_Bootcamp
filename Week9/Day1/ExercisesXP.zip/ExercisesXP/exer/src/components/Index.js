import React from 'react'


function Index() {
  return (
    <>
    <button>+</button>
    <div><div>
    <button>-</button>
    </>
  )
}
export default Index
