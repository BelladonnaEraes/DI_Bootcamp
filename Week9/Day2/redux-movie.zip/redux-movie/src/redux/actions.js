export const MOVIE_DETAIL = 'MOVIE_DETAIL';

export const detail = (movie) => {
  return {
    type: MOVIE_DETAIL,
    payload: movie
  }
}
