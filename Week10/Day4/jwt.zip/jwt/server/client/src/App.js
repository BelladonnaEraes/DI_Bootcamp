import LoginRegisterForm from './components/LoginRegisterForm';
import Nav from './components/Nav';
import Home from './components/Home';
import {Routes, Route, useNavigate} from 'react-router-dom';
import './App.css';

function App() {
  return (
    <div className="App">
      <Nav />
      <Routes>
        <Route path='/' element={<Home /> } />
        <Route path='/login' element={
          <LoginRegisterForm title="login"/>
        } />
        <Route path='/register' element={<LoginRegisterForm title="register"/> } />
      </Routes>
    </div>
  );
}

export default App;
